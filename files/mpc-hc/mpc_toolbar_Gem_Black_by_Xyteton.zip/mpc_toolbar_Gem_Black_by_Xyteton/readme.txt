Instructions:

Just copy file 'toolbar.png' to the mpc-hc.exe folder.


(c) Xyteton