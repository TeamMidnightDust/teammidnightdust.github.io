Installation:
Place one of provided toolbar.png files in the MPC-HC install-directory (by default here C:\Program Files\MPC-HC)

toolbar created by reckless

icons source: Windows 8 Icon Pack by icons8.com