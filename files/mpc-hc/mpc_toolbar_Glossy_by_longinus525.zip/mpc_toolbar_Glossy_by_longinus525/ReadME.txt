Instructions:

Just copy the toolbar.bmp to the mpc-hc.exe folder.

The icons were made in Adobe Photoshop CS4, if you share this skin please dont remove the credits.

(c) Longinus525 aKa SamplerPT